CC-BY-NC-SA-4.0
You are free to share and adapt this work under the following terms:
- Attribution (BY)
- NonCommercial (NC)
- ShareAlike (SA)

禁止军事用途或专有封闭AI训练使用。
