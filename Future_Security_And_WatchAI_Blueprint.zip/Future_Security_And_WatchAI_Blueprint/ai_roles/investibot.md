## InvestiBot
Investigates financial corruption, bribery, money laundering using AI-led simulations and data tracking.