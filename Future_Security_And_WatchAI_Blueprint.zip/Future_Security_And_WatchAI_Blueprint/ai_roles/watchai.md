## WatchAI
Watches all enforcer bots and human officers, flags ethics violations, runs on constitutional override logic.