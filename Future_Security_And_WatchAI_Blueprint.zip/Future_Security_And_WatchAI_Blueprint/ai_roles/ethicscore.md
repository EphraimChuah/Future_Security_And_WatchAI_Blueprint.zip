## EthicsCore
Final moral judgment AI hub that checks each case’s fairness, proportionality, and human dignity.