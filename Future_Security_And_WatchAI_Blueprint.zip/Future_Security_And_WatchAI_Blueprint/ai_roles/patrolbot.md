## PatrolBot
Autonomous patrol robot for non-violent monitoring, conflict mediation, and alerting human responders.