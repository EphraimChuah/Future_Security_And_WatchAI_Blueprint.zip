## GuardAI
Stationed building guardian bot, performs check-in monitoring, visitor scanning, emergency alerts.