## Reverse Override Lock
System that disables AI obedience to unlawful human orders.