## Citizen Appeal Protocol
Anonymous public interface to report AI or human misconduct without registration.